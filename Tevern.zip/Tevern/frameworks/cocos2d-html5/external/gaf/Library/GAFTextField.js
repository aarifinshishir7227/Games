
gaf.TextField = gaf.Object.extend
({
    _className: "GAFTextField"

});