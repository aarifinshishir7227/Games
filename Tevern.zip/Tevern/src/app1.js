var INITIALIZED_1 = false;

var HelloWorldLayer1 = cc.Layer.extend({
    sprite:null,
    ctor:function () {

        this._super();

        var winSize = cc.director.getWinSize();
        var centerPos = cc.p(winSize.width/2, winSize.height/2);


        var sprite = new cc.Sprite.create("shuffle.png");
        sprite.x=winSize.width/2;
        sprite.y = 180;
        this.addChild(sprite);


        var imageNode = new cc.Node();
        imageNode.x = 0;
        imageNode.y = 0;
        this.addChild(imageNode);

        //var targetName = ["11", "12", "13", "14", "15", "16"];
        var posX = [425, 535, 425, 535, 425, 535];
        var posY = [500, 500, 390, 390, 280, 280];

        var sprites = [];
        var shadowSprites = [];


        for(var i=0; i<6; i++)
        {
            var str = (i+11)+".png";
            var target = new cc.Sprite.create(str);
            target.x = posX[i];
            target.y = posY[i];
            //target.setTag(i+1);
            sprites[i] = target;
            imageNode.addChild(target);
        }


        


        if(cc.sys.capabilities.hasOwnProperty('mouse'))
        {
            cc.eventManager.addListener(
            {
                event: cc.EventListener.MOUSE,

                onMouseUp: function(event)
                {

                    var x = event.getLocationX();
                    var y = event.getLocationY();


                    var images = [1, 2, 3, 4, 5, 6];
                    var point = [-1, 25, 100, 85, 10, 30, 75];


                    if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=380 && x<=580) && (y>=152 && y<=208))
                    {
                            for(var j, x, i = images.length; i; j = parseInt(Math.random() * i),
                            x = images[--i], images[i] = images[j], images[j] = x);

                            cc.log("ssssss");
                            for(var i=0; i<6; i++)
                                cc.log(images[i]);

                            for(var i=0; i<6; i++)
                            { 
                                target = sprites[i];
                                imageNode.removeChild(target);
                            }

                            for(var i=0; i<6; i++)
                            {
                                var str = (images[i]+10)+".png";
                                target = new cc.Sprite.create(str);
                                target.x = posX[i];
                                target.y = posY[i];
                                imageNode.addChild(target);
                            }

                            for(var i=0; i<6; i++)
                            {
                                target = new cc.Sprite.create("shadow.png");
                                target.x = posX[i];
                                target.y = posY[i];
                                shadowSprites[i] = target;
                                imageNode.addChild(target);
                            }
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=375 && x<=475) && (y>=450 && y<=550))
                    {
                        imageNode.removeChild(shadowSprites[0]);
                        var getIndex = images[0];
                        score += point[getIndex];
                        cc.log(score);

                        INITIALIZED_1 = false;
                        cc.director.popScene(score);
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=485 && x<=585) && (y>=450 && y<=550))
                    {
                        imageNode.removeChild(shadowSprites[1]);
                        var getIndex = images[1];
                        score += point[getIndex];
                        cc.log(score);

                        INITIALIZED_1 = false;
                        cc.director.popScene(score);
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=375 && x<=475) && (y>=340 && y<=440))
                    {
                        imageNode.removeChild(shadowSprites[2]);
                        var getIndex = images[2];
                        score += point[getIndex];
                        cc.log(score);

                        INITIALIZED_1 = false;
                        cc.director.popScene(score);
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=485 && x<=585) && (y>=340 && y<=440))
                    {
                        imageNode.removeChild(shadowSprites[3]);
                        var getIndex = images[3];
                        score += point[getIndex];
                        cc.log(score);

                        INITIALIZED_1 = false;
                        cc.director.popScene(score);
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=375 && x<=475) && (y>=230 && y<=330))
                    {
                        imageNode.removeChild(shadowSprites[4]);
                        var getIndex = images[4];
                        score += point[getIndex];
                        cc.log(score);

                        INITIALIZED_1 = false;
                        cc.director.popScene(score);
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=485 && x<=585) && (y>=230 && y<=330))
                    {
                        imageNode.removeChild(shadowSprites[5]);
                        var getIndex = images[5];
                        score += point[getIndex];
                        cc.log(score);

                        INITIALIZED_1 = false;
                        cc.director.popScene(score);
                    }



                    /*labelName[1].setString(score.toString());
                    labelName[3].setString(cnt.toString());*/

                }
            }, this);

        }






        
        return true;
    }

});

function ccnode()
{
    var node = cc.Node();
    node.addChild(layer);
    
    return node;
}

var HelloWorldScene1 = cc.Scene.extend({
    onEnter:function () {
        this._super();

        if(INITIALIZED_1==false)
        {
            INITIALIZED_1 = true;

            var layer = new HelloWorldLayer1();
            this.addChild(layer);
        }

        /*var layer = new HelloWorldLayer();
        this.addChild(layer);*/
    }
});