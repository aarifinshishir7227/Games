var INITIALIZED = false;

var winSize;
var centerPos;
var spinLeft;
var spinFlag = true;
var shuffleFlag = false;
var coinScore;
var jamesScore;
var foodScore;
var eggScore;
var decorScore;
var battleScore;
var wishScore;
var labelName = ["scoreTag", "scoreCurrent", "spinCnt", "spinCurrent"];
var imageNode;
var rotationPoint;
var pointLabel;
var pointLabelNode;
var decisionNode;
var realSprites = [];




var HelloWorldLayer = cc.Layer.extend({
    sprite:null,
    ctor:function () {

        this._super();

        winSize = cc.director.getWinSize();
        centerPos = cc.p(winSize.width/2, winSize.height/2);


        /*var draw = new cc.DrawNode();
        this.addChild(draw, 10);
        

        draw.drawCircle(centerPos, 100, 0, 10, false, 2, cc.color(0, 255, 0, 255));
        draw.drawCircle(centerPos, 180, cc.degreesToRadians(150), 100, false, 10, cc.color(0, 255, 255, 255));*/


        this.addImagesToLayer();
        this.addLabelsToLayer();
        this.addNodesToLayer();

        var selectNodeImagePosX = [];
        var selectNodeImagePosY = [];
        var selectNodeImage = [];
        var imagesAfter = [];

        

        var target = new cc.Sprite.create("giveup.png");
        target.x = 700;
        target.y = 100;
        imageNode.addChild(target);




        var sprites = [];
        var shadowSprites = [];
        var fakeSprites = [];
        

        var posX = [365, 475, 585, 365, 475, 585, 365, 475, 585];
        var posY = [500, 500, 500, 390, 390, 390, 280, 280, 280];


        var IMAGES = [1, 2, 3, 4, 5, 6, 7, 8, 9];
        var images = [1, 2, 3, 4, 5, 6, 7, 8, 9];
        var point = [-1, 1, 800, 125, 600, 2, 150, 400, 50, 75];

        var fakeImages = [6, 6, 6, 6, 6, 5, 7, 8, 2];

        var c=0;
        eggScore=0;
        decorScore=0;
        battleScore=0;
        wishScore=0;
        jamesScore=0;
        
        if(cc.sys.capabilities.hasOwnProperty('mouse'))
        {
            cc.eventManager.addListener(
            {
                event: cc.EventListener.MOUSE,


                removeInitialImages: function()
                {
                    //======remove the initial images============
                    for(var i=0; i<9; i++)
                    { 
                        target = sprites[i];
                        imageNode.removeChild(target);
                    }
                    //==========================================
                },

                generateFakeImagePosition: function()
                {
                    for(var j, x, i = fakeImages.length; i; j = parseInt(Math.random() * i),
                            x = fakeImages[--i], fakeImages[i] = fakeImages[j], fakeImages[j] = x);
                },

                generateRandomPosition: function(position)
                {
                    for(var j, x, i = images.length; i; j = parseInt(Math.random() * i),
                            x = images[--i], images[i] = images[j], images[j] = x);

                    for(var i=0; i<9; i++)
                    {
                        if(i==position)
                        {
                            imagesAfter[i] = fakeImages[0];
                        }
                        else if(images[i] == fakeImages[0])
                        {
                            imagesAfter[i] = images[position];
                        }
                        else
                            imagesAfter[i] = images[i];

                        cc.log("Random Position");

                    }
                },

                addFakeImages: function()
                {
                    for(i=0; i<9; i++)
                    {   
                        var str = (fakeImages[0]+10)+".png";
                        target = new cc.Sprite.create(str);
                        target.x = posX[i];
                        target.y = posY[i];
                        fakeSprites = target;
                        imageNode.addChild(target);
                        cc.log("Fake Image[0] = "+fakeImages[0]);
                    }
                },

                removeFakeImages: function()
                {
                    for(var i=0; i<9; i++)
                    {
                        //target = fakeSprites[i];
                        imageNode.removeChild(fakeSprites[i]);
                        cc.log("Remove");
                    }

                },

                addNewImagesRandomly: function()
                {
                    //===============add new images randomly==============
                    for(var i=0; i<9; i++)
                    {
                        var str = (imagesAfter[i]+10)+".png";
                        target = new cc.Sprite.create(str);
                        target.x = posX[i];
                        target.y = posY[i];
                        imageNode.addChild(target);
                        cc.log(imagesAfter[i]);
                    }
                    //===================================================
                },

                addShadowToImages: function(indx)
                {
                    //==============add shadow image to all images=====================
                    for(var i=0; i<9; i++)
                    {
                        if(i==indx)
                            continue;

                        target = new cc.Sprite.create("shadow.png");
                        target.x = posX[i];
                        target.y = posY[i];
                        shadowSprites[i] = target;
                        imageNode.addChild(target);
                    }
                    //================================================================
                },

                updateScore: function(indx)
                {
                    if(c>0)
                    {
                        //jamesScore--;
                        jamesScore -= c;
                        labelName[3].setString(jamesScore.toString());
                        cc.log("C  "+c);
                    }
                    
                    c++;

                    //========remove shadow image=================================
                    imageNode.removeChild(shadowSprites[indx]);

                    //=========================================================
                    //var getIndex = images[indx];
                    var getIndex = imagesAfter[indx];
                    if(getIndex==1)
                    {
                        eggScore += point[getIndex];

                        // pointLabel = new cc.LabelTTF("1 Egg", "Arial", 20);
                        // pointLabel.setColor(cc.color(231, 178, 52));
                        // pointLabel.x = winSize.width/2;
                        // pointLabel.y = winSize.height/2;
                        // imageNode.addChild(pointLabel);

                        // // target = new cc.Sprite.create((imagesAfter[getIndex-1]+10)+".png");
                        // // target.x = winSize.width/2;
                        // // target.y = winSize.height/2-48;
                        // // imageNode.addChild(target);

                        // pointLabel.runAction(cc.FadeOut.create(2));                      
                        // //target.runAction(cc.FadeOut.create(2));                      
                    }
                    else if(getIndex==5)
                    {
                        jamesScore += point[getIndex];
                    }
                    else if(getIndex==2 || getIndex==4 || getIndex==6 || getIndex==7)
                    {
                        coinScore += point[getIndex];
                    }
                    else if(getIndex==3 || getIndex==8 || getIndex==9)
                    {
                        foodScore += point[getIndex];
                    }

                    cc.log("Current Situation");
                    cc.log("Egg: "+eggScore);
                    cc.log("Decor: "+decorScore);
                    cc.log("Battle: "+battleScore);
                    cc.log("Wish: "+wishScore);
                    cc.log("james: "+jamesScore);
                    cc.log("Coin: "+coinScore);
                    cc.log("Food: "+foodScore);

                    if(/*jamesScore==0*/ jamesScore < c+1)
                    {
                        setTimeout(function(){
                            c=0;
                            shuffleFlag=false;
                            spinFlag=true;
                            decisionNode.setVisible(false);
                            imageNode.setVisible(false);
                            imageNode.removeAllChildren();
                            rotationPoint.setVisible(true);
                            realSprites[0].setVisible(true);
                            realSprites[1].setVisible(true);
                            cc.log("C  "+c);
                        }, 1000);
                    }
                },

                nodeStatus: function()
                {
                    if(c>0 && c!=9)
                    {
                        labelText.setString("Try your luck again cost "+c+" James");
                        decisionNode.setVisible(true);
                    }
                        
                    if(c==9)
                    {
                        c=0;
                        shuffleFlag = false;
                        spinFlag=true;
                        setTimeout(function(){
                            decisionNode.setVisible(false);
                            imageNode.setVisible(false);
                            imageNode.removeAllChildren();
                            rotationPoint.setVisible(true);
                            realSprites[0].setVisible(true);
                            realSprites[1].setVisible(true);
                        }, 1000);

                        cc.log("C  "+c);
                    }
                },

                onMouseUp: function(event)
                {
                    var x = event.getLocationX();
                    var y = event.getLocationY();
                    

                    if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=380 && x<=580) && (y>=152 && y<=208) && spinFlag==false && shuffleFlag==false)
                    {
                            shuffleFlag = true;
                            this.removeInitialImages();
                            this.generateFakeImagePosition();
                            this.addFakeImages();
                            this.addShadowToImages(-1);
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=315 && x<=415) && (y>=450 && y<=550) && c<9 && shuffleFlag)
                    {
                        if(c==0)
                        {
                            this.removeFakeImages();
                            this.generateRandomPosition(0);
                            this.addNewImagesRandomly();
                            this.addShadowToImages(0);
                        }
                        this.updateScore(0);
                        this.nodeStatus();
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=425 && x<=525) && (y>=450 && y<=550) && c<9 && shuffleFlag)
                    {
                        if(c==0)
                        {
                            this.removeFakeImages();
                            this.generateRandomPosition(1);
                            this.addNewImagesRandomly();
                            this.addShadowToImages(1);
                        }
                        this.updateScore(1);
                        this.nodeStatus();
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=535 && x<=635) && (y>=450 && y<=550) && c<9 && shuffleFlag)
                    {
                        if(c==0)
                        {
                            this.removeFakeImages();
                            this.generateRandomPosition(2);
                            this.addNewImagesRandomly();
                            this.addShadowToImages(2);
                        }
                        this.updateScore(2);
                        this.nodeStatus();
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=315 && x<=415) && (y>=340 && y<=440) && c<9 && shuffleFlag)
                    {
                        if(c==0)
                        {
                            this.removeFakeImages();
                            this.generateRandomPosition(3);
                            this.addNewImagesRandomly();
                            this.addShadowToImages(3);
                        }
                        this.updateScore(3);
                        this.nodeStatus();
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=425 && x<=525) && (y>=340 && y<=440) && c<9 && shuffleFlag)
                    {
                        if(c==0)
                        {
                            this.removeFakeImages();
                            this.generateRandomPosition(4);
                            this.addNewImagesRandomly();
                            this.addShadowToImages(4);
                        }
                        this.updateScore(4);
                        this.nodeStatus();
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=535 && x<=635) && (y>=340 && y<=440) && c<9 && shuffleFlag)
                    {
                        if(c==0)
                        {
                            this.removeFakeImages();
                            this.generateRandomPosition(5);
                            this.addNewImagesRandomly();
                            this.addShadowToImages(5);
                        }
                        this.updateScore(5);
                        this.nodeStatus();
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=315 && x<=415) && (y>=230 && y<=330) && c<9 && shuffleFlag)
                    {
                        if(c==0)
                        {
                            this.removeFakeImages();
                            this.generateRandomPosition(6);
                            this.addNewImagesRandomly();
                            this.addShadowToImages(6);
                        }
                        this.updateScore(6);
                        this.nodeStatus();
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=425 && x<=525) && (y>=230 && y<=330) && c<9 && shuffleFlag)
                    {
                        if(c==0)
                        {
                            this.removeFakeImages();
                            this.generateRandomPosition(7);
                            this.addNewImagesRandomly();
                            this.addShadowToImages(7);
                        }
                        this.updateScore(7);
                        this.nodeStatus();
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=535 && x<=635) && (y>=230 && y<=330) && c<9 && shuffleFlag)
                    {
                        if(c==0)
                        {
                            this.removeFakeImages();
                            this.generateRandomPosition(8);
                            this.addNewImagesRandomly();
                            this.addShadowToImages(8);
                        }
                        this.updateScore(8);
                        this.nodeStatus();
                    }
                    else if(event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=650 && x<=750) && (y>=50 && y<=150))
                    {
                        c=0;
                        shuffleFlag=false;
                        spinFlag=true;
                        decisionNode.setVisible(false);
                        imageNode.setVisible(false);
                        imageNode.removeAllChildren();
                        rotationPoint.setVisible(true);
                        realSprites[0].setVisible(true);
                        realSprites[1].setVisible(true);
                        cc.log("C  "+c);
                    }


                    setTimeout(function(){
                        labelName[1].setString(coinScore.toString());
                        labelName[3].setString(jamesScore.toString());
                        labelName[5].setString(foodScore.toString());
                        labelName[7].setString(spinLeft.toString());
                        
                    }, 1000);
                }

            }, this);

        }


        //===========================add label to decision Node=======================
        labelText = new cc.LabelTTF("Try your luck again cost 1 Jame", "Arial", 20);
        labelText.setColor(cc.color(231, 178, 52));
        labelText.x = winSize.width/2;
        labelText.y = 130
        decisionNode.addChild(labelText);

        //==========position and angle of images which added to rotationPoint node==========
        var posx = [-1, 0, 77, 123, 123, 76, 0, -76, -122, -122, -77];
        var posy = [-1, 130, 105, 40, -40, -105, -130, -105, -40, 40, 103];
        var anglePos = [-1, 0, 36, 72, 108, 144, 180, 216, 252, 288, 324];


        //=========add image to rotationPoint node with angle=====================
        var target;

        for(var i=1; i<=10; i++)
        {
            var str = "res/img"+i+".png";
            target = cc.Sprite.create(str);
            target.setPosition(posx[i], posy[i]);
            target.runAction(cc.RotateTo.create(0, anglePos[i]));
            rotationPoint.addChild(target);
        }
        //=======================================================================

        

        //================when spin button clicked=============================
        spinLeft=30;
        coinScore=200;
        jamesScore=45;
        foodScore=100;

        if(cc.sys.capabilities.hasOwnProperty('mouse'))
        {
            cc.eventManager.addListener(
            {
                event: cc.EventListener.MOUSE,

                onMouseUp: function(event)
                {
                    var x = event.getLocationX();
                    var y = event.getLocationY();
                    if( event.getButton()==cc.EventMouse.BUTTON_LEFT && (x>=430 && x<=530) && (y>=75 && y<=125) && spinLeft && shuffleFlag==false && spinFlag==true)
                    {
                        spinLeft--;

                        //====set point for individual images=============================
                        var index = [-1, 1, 2, 3, 4, 5 ,6, 7, 8, 9, 10];
                        var point = [-1, 25, 50, 0, 100, 1, 0, 50, 0, 150, 0];
                        //===============================================================



                        //=============generate random number for angle for rotate node==============
                        var random = Math.floor((Math.random()*10)+36)*36;

                        var rotatePoint = new cc.rotateTo(2, random);
                        var easeSineInOutAction = new cc.EaseSineInOut(rotatePoint);
                        rotationPoint.runAction(easeSineInOutAction);
                        //===========================================================================


                        //============calculation for get the point for specific image============
                        if(random>=360)
                        {
                            while(random>=360)
                                random = random-360;
                        }

                        var add = random/36;

                        for(var i=1; i<=10; i++)
                        {
                            index[i] = index[i]+(10-add);

                            if(index[i]>10)
                                index[i] %= 10;
                        }
                        //========================================================================
						
						
						
						setTimeout(function(){
							
							var getIndex;
							getIndex = index[1];

                            if(getIndex==1 || getIndex==7)
                            {
                                foodScore += point[getIndex];
                                
                                pointLabel = new cc.LabelTTF(""+point[getIndex]+" Foods", "Arial", 20);
                                pointLabel.setColor(cc.color(231, 178, 52));
                                pointLabel.x = 0;
                                pointLabel.y = -48;
                                pointLabelNode.addChild(pointLabel);

                                target = cc.Sprite.create("res/img"+index[1]+".png");
                                target.x = 0;
                                target.y = 0;
                                pointLabelNode.addChild(target);

                                pointLabel.runAction(cc.FadeOut.create(2));
                                target.runAction(cc.FadeOut.create(2));
                            }
                                
                            else if(getIndex==2 || getIndex==4 || getIndex==9)
                            {
                                coinScore += point[getIndex];

                                pointLabel = new cc.LabelTTF(""+point[getIndex]+" Coins", "Arial", 20);
                                pointLabel.setColor(cc.color(231, 178, 52));
                                pointLabel.x = 0;
                                pointLabel.y = -48;
                                pointLabelNode.addChild(pointLabel);

                                target = cc.Sprite.create("res/img"+index[1]+".png");
                                target.x = 0;
                                target.y = 0;
                                pointLabelNode.addChild(target);
                                
                                pointLabel.runAction(cc.FadeOut.create(2));
                                target.runAction(cc.FadeOut.create(2));
                            }
                                
                            else if(getIndex==5)
                            {
                                jamesScore += 1;

                                pointLabel = new cc.LabelTTF(""+point[getIndex]+" Jame", "Arial", 20);
                                pointLabel.setColor(cc.color(231, 178, 52));
                                pointLabel.x = 0;
                                pointLabel.y = -48;
                                pointLabelNode.addChild(pointLabel);

                                target = cc.Sprite.create("res/img"+index[1]+".png");
                                target.x = 0;
                                target.y = 0;
                                pointLabelNode.addChild(target);
                                
                                pointLabel.runAction(cc.FadeOut.create(2));
                                target.runAction(cc.FadeOut.create(2));
                            }
                                		
							else
							{
                                pointLabel = new cc.LabelTTF("Box", "Arial", 20);
                                pointLabel.setColor(cc.color(231, 178, 52));
                                pointLabel.x = 0;
                                pointLabel.y = -48;
                                pointLabelNode.addChild(pointLabel);

                                target = cc.Sprite.create("res/img"+index[1]+".png");
                                target.x = 0;
                                target.y = 0;
                                pointLabelNode.addChild(target);
                                
                                pointLabel.runAction(cc.FadeOut.create(2));
                                target.runAction(cc.FadeOut.create(2));


                                setTimeout(function(){
                                    var sprite = new cc.Sprite.create("shuffle.png");
                                sprite.x=winSize.width/2;
                                sprite.y = 180;
                                imageNode.addChild(sprite);

                                //=========create random number for shuffle images initially==============                              
                                for(var j, x, i = images.length; i; j = parseInt(Math.random() * i),
                                    x = images[--i], images[i] = images[j], images[j] = x);
                                
                                //===========add images to imageNode======================
                                target = new cc.Sprite.create("giveup.png");
                                target.x = 700;
                                target.y = 100;
                                imageNode.addChild(target);

                                for(var i=0; i<9; i++)
                                {
                                    var str = (images[i]+10)+".png";
                                    var target = new cc.Sprite.create(str);
                                    target.x = posX[i];
                                    target.y = posY[i];
                                    sprites[i] = target;
                                    imageNode.addChild(target);
                                }
                                //========================================================

                                imageNode.setVisible(true);
                                //decisionNode.setVisible(true);
                                rotationPoint.setVisible(false);
                                realSprites[0].setVisible(false);
                                realSprites[1].setVisible(false);
                                spinFlag = false;
                                }, 2000)
								
							}

                            labelName[1].setString(coinScore.toString());
                            labelName[3].setString(jamesScore.toString());
							labelName[5].setString(foodScore.toString());
							labelName[7].setString(spinLeft.toString());
							
						}, 2100);
                        
                        labelName[1].setString(coinScore.toString());
                        labelName[3].setString(jamesScore.toString());
                        labelName[5].setString(foodScore.toString());
                        labelName[7].setString(spinLeft.toString());
                    
                    }
                }
            }, this);
        }
        
        return true;
    },

    addImagesToLayer: function()
    {
        //=========add pointer image and spin button to layer================
        var sprites = ["pointer", "spin",];
        var spritesPosX = [winSize.width/2, 480];
        var spritesPosY = [winSize.height/2+190, 100];

        for(var i=0; i<2; i++)
        {
            var str = "res/"+sprites[i]+".png";
            var target = cc.Sprite.create(str);
            target.x = spritesPosX[i];
            target.y = spritesPosY[i];
            realSprites[i] = target;
            this.addChild(target);
        }
        //=======================================================================
    },

    addLabelsToLayer: function()
    {
        //=======================score and spin left lable added to layer============== 
        var labelText = ["Coin   ", "200", "James   ", "45", "Food   ", "100", "Spin Left   ", "30"];
        var labelposX = [800, 900, 800, 900, 800, 900, 100, 200];
        var labelposY = [570, 570, 520, 520, 470, 470, 570, 570];

        for(var i=0; i<8; i++)
        {
            labelName[i] = new cc.LabelTTF(labelText[i], "Arial", 40);
            labelName[i].setColor(cc.color(231, 178, 52));
            labelName[i].x = labelposX[i];
            labelName[i].y = labelposY[i];
            this.addChild(labelName[i]);
        }
        //================================================================================
    },

    addNodesToLayer: function()
    {
        //=================create Node rotationPoint to add images properly======================
        rotationPoint = new cc.Node();
        rotationPoint.x = winSize.width/2;
        rotationPoint.y = winSize.height/2;
        this.addChild(rotationPoint);
        //================================================================

        pointLabelNode = new cc.Node();
        pointLabelNode.x = winSize.width/2;;
        pointLabelNode.y = winSize.height/2;
        this.addChild(pointLabelNode);

        imageNode = new cc.Node();
        imageNode.x = 0;
        imageNode.y = 0;
        this.addChild(imageNode);
        imageNode.setVisible(false);

        decisionNode = new cc.Node();
        decisionNode.x = 0;
        decisionNode.y = 0;
        this.addChild(decisionNode);
        decisionNode.setVisible(false);
    },

});


var HelloWorldScene = cc.Scene.extend({
    onEnter:function () {
        this._super();

        var layer = new HelloWorldLayer();
        this.addChild(layer);
    }
});

